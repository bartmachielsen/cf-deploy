#!/usr/bin/env python

import argparse
import glob
import logging
import os
import time
from pathlib import Path

import boto3
import yaml
from botocore.exceptions import ClientError
from deepmerge import always_merger
from yaml import Loader
from cf_deploy.utils.logging import configure_structlog
import structlog

# Configure logging
configure_structlog()
logging.basicConfig(level=logging.INFO)
log = structlog.get_logger("cf-deploy")


def track_stack_events(stack_name, region):
    cf = boto3.client('cloudformation', region_name=region)
    seen_event_ids = set()

    while True:
        events = cf.describe_stack_events(StackName=stack_name)

        for event in reversed(events['StackEvents']):
            event_id = event['EventId']
            if event_id not in seen_event_ids:
                log.info(
                    "Stack event",
                    timestamp=event['Timestamp'],
                    resource_status=event['ResourceStatus'],
                    resource_type=event['ResourceType'],
                    logical_resource_id=event['LogicalResourceId'],
                )
                seen_event_ids.add(event_id)

        stack = cf.describe_stacks(StackName=stack_name)
        stack_status = stack['Stacks'][0]['StackStatus']

        if stack_status.endswith('_COMPLETE') or stack_status.endswith('_FAILED'):
            break

        time.sleep(10)


def deploy_stack(config, name, region_name):
    cf = boto3.client('cloudformation', region_name=region_name)

    try:
        cf.create_stack(
            StackName=name,
            TemplateBody=config['template'],
            Parameters=[{'ParameterKey': k, 'ParameterValue': str(v)} for k, v in config['parameters'].items()],
            Tags=[{'Key': k, 'Value': str(v)} for k, v in {**config['tags'], 'Name': name}.items()],
            Capabilities=config.get('capabilities', []),
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'AlreadyExistsException':
            cf.update_stack(
                StackName=name,
                TemplateBody=config['template'],
                Parameters=[{'ParameterKey': k, 'ParameterValue': str(v)} for k, v in config['parameters'].items()],
                Tags=[{'Key': k, 'Value': str(v)} for k, v in {**config['tags'], 'Name': name}.items()],
                Capabilities=config.get('capabilities', []),
            )

    # Monitor stack creation
    waiter = cf.get_waiter('stack_create_complete')
    waiter.wait(StackName=name)


def main():
    parser = argparse.ArgumentParser(description='Automate CloudFormation deployments')
    parser.add_argument('-c', '--config', required=True, help='Config file or multiple files when using a pattern')
    parser.add_argument('-b', '--base', help='Base configs file to use', nargs="*")

    args = parser.parse_args()

    # Parse base configs if given
    base_config = {}
    if args.base:
        for base_config_path in args.base:
            log.info("Loading base config", base_config_path=base_config_path)
            with open(base_config_path, 'r') as base_config_file:
                base_config = always_merger.merge(base_config, yaml.load(base_config_file, Loader=Loader))

    for file_location in glob.glob(args.config):
        with open(file_location, 'r') as config_file:
            log.info("Loading config", file_location=file_location)

            config = always_merger.merge(base_config, yaml.load(config_file, Loader=Loader))
            name = (config.get('prefix', '') + config.get('name', '') or Path(file_location).stem)

            if not config.get('parameters'):
                config["parameters"] = {}

            # Resolving references
            for conf_key, conf_val in config['parameters'].items():
                if conf_val.startswith('!') and config['parameters'].get(conf_val[1:]):
                    log.info(
                        "Resolving reference",
                        conf_key=conf_key,
                        conf_val=conf_val,
                        resolved_val=config["parameters"][conf_val[1:]]
                    )
                    config['parameters'][conf_key] = config['parameters'][conf_val[1:]]

            # Determining stage
            stage = config['parameters'].get('Stage', os.environ.get('DEPLOY_STAGE'))
            region_name = config['parameters'].get('Region', os.environ.get('DEPLOY_REGION', os.environ.get('AWS_DEFAULT_REGION')))

            if config.get('deployment_stages') and stage not in config['deployment_stages']:
                log.info("Skipping deployment", name=name, stage=stage, reason="Not in deploy stages for this environment")
                continue

            # Setting default tags
            if not config.get('tags'):
                config["tags"] = {
                    "Environment": stage,
                    "Name": name,
                }

            log.info("Deploying", name=name, stage=stage)

            if config['template'].startswith('s3://'):
                bucket, key = config['template'][5:].split('/', 1)
                log.info("Downloading from S3", template=config["template"])
                s3 = boto3.client('s3', region_name=config['region'])
                response = s3.get_object(Bucket=bucket, Key=key)
                config['template'] = response['Body'].read().decode('utf-8')

            deploy_stack(config, name, region_name)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log.exception(e)
